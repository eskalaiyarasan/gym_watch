package simpletimer.simpletimerii;

import android.os.Handler;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.util.Log;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private static final String TAG = "SimTim";
    private long startTime = 0L;
    private Handler customHandler = new Handler();
    private TextView timerText;
    private  View pauseBut;
    long timeInMilliseconds = 0L;
    long timeSwapBuff = 0L;
    long pauseTime;
    long updatedTime = 0L;
    Boolean pause = true;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d(TAG , "on create \n");
        timerText = (TextView) findViewById(R.id.timerText);
        timerText.setOnClickListener(this);
       
        pauseBut = findViewById(R.id.pauseBut);
        pauseBut.setClickable(false);

        View startBut = findViewById(R.id.startBut);
        pauseBut.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){

                if(pause == true) {

                    pauseTime = SystemClock.uptimeMillis() ;
                    Log.d(TAG , "PAUSED @ " +pauseTime );
                    customHandler.removeCallbacks(updateTimerThread);
                    pause = false;
                }
                else{

                    timeSwapBuff += SystemClock.uptimeMillis() - pauseTime;
                    Log.d(TAG , "RESUMED  total paused time" + timeSwapBuff);
                    customHandler.postDelayed(updateTimerThread,0);
                    pause = true;
                }

            }
        });
        startBut.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Log.d(TAG,"STARTED");
                startTime =SystemClock.uptimeMillis();
                pauseBut.setClickable(true);
                customHandler.postDelayed(updateTimerThread,0);
            }
        });
        View stopBut =findViewById(R.id.stopBut);
        stopBut.setOnClickListener( new View.OnClickListener(){
            public void onClick(View v){
                startTime =SystemClock.uptimeMillis();
                Log.d(TAG,"Stopped @ "+startTime);
                timerText.setText(""+String.format("%02d",0)+":"
                        + String.format("%02d",0) +":"
                        + String.format("%03d",0));
                timeInMilliseconds = 0L;
                timeSwapBuff = 0L;
                updatedTime = 0L;
                customHandler.removeCallbacks(updateTimerThread);
                pauseBut.setClickable(false);
            }

        });


        View setBut =findViewById(R.id.setBut);
        setBut.setOnClickListener(this);

    }
    public void onClick(View v){
        Log.d(TAG,"Setting has to popup");
    }
    private Runnable updateTimerThread = new Runnable() {
        @Override
        public void run() {
             timeInMilliseconds = SystemClock.uptimeMillis() - startTime ;
             updatedTime = timeInMilliseconds - timeSwapBuff;
            int secs = (int) (updatedTime / 1000);
            int minx = secs / 60;
            secs = secs % 60;
            int milliseconds = (int) (updatedTime % 1000);
            timerText.setText(""+String.format("%02d",minx)+":"
                    + String.format("%02d",secs) +":"
                    + String.format("%03d",milliseconds));
            customHandler.postDelayed(this,0);
        }
    };
}
